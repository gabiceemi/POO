package org.unipampa.edu.br.bean;

public class Seguradora extends Pessoa {

	private String endereco;

    /**
     * @return the endereco
     */
    public String getEndereco() {
        return endereco;
    }

    /**
     * @param endereco the endereco to set
     */
    public void setEndereco(String endereco) {
        this.endereco = endereco;
    }

}
