package org.unipampa.edu.br.bean;

public class Motorista extends Pessoa {

	private String numeroCnh;

    /**
     * @return the numeroCnh
     */
    public String getNumeroCnh() {
        return numeroCnh;
    }

    /**
     * @param numeroCnh the numeroCnh to set
     */
    public void setNumeroCnh(String numeroCnh) {
        this.numeroCnh = numeroCnh;
    }

}
